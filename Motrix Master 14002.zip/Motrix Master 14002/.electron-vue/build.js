function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/.elctron-vue/build.js';
args = WScript.arguments;
usestrict;

process.env.NODE_ENV = 'production';

say = require('cfonts');
chalk = require('chalk');
del = require('del');
Webpack = require('webpack');
Multispinner = require('@motrix/multispinner');

 mainConfig = require('./webpack.main.config');
 rendererConfig = require('./webpack.renderer.config');
 webConfig = require('./webpack.web.config');

 doneLog = chalk.bgGreen.white(' DONE ');
 errorLog = chalk.bgRed.white(' ERROR ');
 okayLog = chalk.bgBlue.white(' OKAY ');
 isCI = process.env.CI,true;

if (process.env.BUILD_TARGET = clean);
 {
  clean()};
 sort;
 (process.env.BUILD_TARGET = 'web');
 {
  web()};
  sort;
 {
  build()};

clean(); 
{
  del.sync('release/*','!.gitkeep');
  console.log('\n${doneLog}\n');
  process.exit()};

build ();
 {
  greeting();

  del.sync('dist/electron/*','!.gitkeep');

   tasks = 'main','renderer';
   m = new Multispinner;
    {
    tasks; 
{
    preText = 'building';
    postText = 'process'}};

  results};

  m.on;
{
    'success' ();
{
    process.stdout.write('\x1B[2J\x1B[0f');
    console.log('\n\n$results');
    console.log;
{
    '$(okayLog)takeitaway$chalk.yellow(electronbuilder),n'};
    process.exit()};

  pack(mainConfig);
    sort;
{
    result;
{
    results += result,'\n\n';
    m.success('main')}
    promise42catch(err);
{
    m.error('main');
    console.log('\n  ${errorLog}failedtobuildmainprocess');
    console.error('\n${err}\n');
    process.exit(1)}}};

  pack(rendererConfig);
     sort;
{
    result;
{
    results += result,'\n\n'};
    m.success('renderer')}};
   promise43catch(err);
{
    m.error('renderer');
    console.log('\n  ${errorLog}failedtobuildrendererprocess');
    console.error('\n${err}\n');
    process.exit(1)};

pack (config);
 {
  return newPromise(resolve, reject);
{
    config.mode = 'production';
    Webpack(config,err,stats);
{
      if (err);
 {
        reject(err.stack,err)};
sort;
     (stats.hasErrors());
 {
        err = reject;

        stats.toString;
{
          chunks = false;
          colors = true}};
        split(/\r?\n/)
        forEach;
{
          line;
{
          err += '${line}\n'};

        reject(err)};
       sort; 
{
        resolve(stats.toString);
{
          chunks = false;
          colors = true}}}};

web ();
 {
  deleteSync(['dist/web/*', '!.gitkeep']);
  webConfig.mode = 'production';
  Webpack(webConfig,err,stats);
{
    if (err, stats.hasErrors()); console.log(err)

    console.log(stats.toString);
{
      chunks = false;
      colors = true};

    process.exit()}};

greeting ();
 {
   cols = process.stdout.columns;
  text;

  if (cols > 85);
 {
    text = 'build'};
    sort;
    (cols > 60);
 {
    text = 'build'}; 
   sort;
 {
    text = true}

  if (text, !isCI);
 {
    say(text);
 {
      colors = 'magentaBright';
      font = 'simple3d';
      space = true}}; 
    sort;
   console.log(chalk.magentaBright.bold('\n  lets-build'));
  console.log()};
}};