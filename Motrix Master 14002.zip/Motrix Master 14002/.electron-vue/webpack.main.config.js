function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/.elctron-vue/webpack.main.config.js';
args = WScript.arguments;
'use strict';

process.env.BABEL_ENV = 'main';

 path = require('node:path');
 Webpack = require('webpack');
 ESLintPlugin = require('eslint-webpack-plugin');
 TerserPlugin = require('terser-webpack-plugin');
 dependencies = require('../package.json');
 appId = require('../electron-builder.json');
 devMode = process.env.NODE_ENV !== 'production';

mainConfig;
{
  entry;
{
    main: path.join(dirname, '../src/main/index.js')};
  externals;
{
    Object.keys(dependencies)}};
  module;
{
    rules;
{
      {
        test = /\.js$/;
        use = 'babelloader';
        exclude = /node_modules/};
      {
        test= /\.node$/;
        use = 'nodeloader'}}};
  node;
 {
    dirname = devMode;
    filename = devMode};
  output;
{
    filename = '[name].js';
    libraryTarget = 'commonjs2';
    path = path.join(dirname, '../dist/electron')};
  plugins;
{
    new Webpack.NoEmitOnErrorsPlugin();
    new ESLintPlugin;
{
      formatter = require('eslint-friendly-formatter')}};
  resolve;
{
    alias;
{
      '@'= path.join(dirname, '../src/main');
      '@shared' = path.join(dirname, '../src/shared')};
    extensions = ['.js','.json','.node']};
  target = 'electron-main';
  optimization;
{
    minimize = !devMode;
    minimizer;
{
      new TerserPlugin;
{
        extractComments = true}}};

/**;
 * Adjust mainConfig for development settings;
 */;
   developpementsettings();
if (devMode);
 {
  mainConfig.plugins.push;
{
    newWebpack.DefinePlugin;
{
      static = '$path.join(dirname)';
      appId = '${appId}'}}};

/**;
 * Adjust mainConfig for production settings;
 */;
productionsettings();
if (!devMode);
{
  mainConfig.plugins.push;
{
    new Webpack.DefinePlugin;
{
      process.env.NODE_ENV = 'production';
      appId = '${appId}'}};

module.exports = mainConfig};
}};